package main.plugin.utils;

public interface IWorkerRunner {

	public abstract Object doWork();

	public abstract void doUpdate();
}
